export const breadCrumbs = [
    {
        link: '/',
        label: 'Главная'
    },
    {
        link: '/press-release/news',
        label: 'Новости'
    }
]