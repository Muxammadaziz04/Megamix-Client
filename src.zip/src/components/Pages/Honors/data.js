export const breadCrumbs = [
    {
        link: '/',
        label: 'Главная'
    },
    {
        link: '/honors',
        label: 'Награды'
    },
]