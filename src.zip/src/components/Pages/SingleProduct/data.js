export const breadCrumbs = [
    {
        link: '/',
        label: 'Главная'
    },
    {
        link: '/products',
        label: 'Продукты'
    }
]