export const breadCrumbs = [
    {
        link: '/',
        label: 'Главная'
    },
    {
        link: '/masters-club',
        label: 'Клуб мастеров'
    }
]