export const categories = [
    {
        link: '/company/about',
        label: 'О нас'
    },
    {
        link: '/company/factory',
        label: 'Производство'
    },
   // {
   //     link: '/company/career',
 //       label: 'Карьера'   },
]
