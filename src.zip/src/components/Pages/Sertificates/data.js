export const breadCrumbs = [
    {
        link: '/',
        label: 'Главная'
    },
    {
        link: '/sertificates',
        label: 'Сертификаты'
    },
]