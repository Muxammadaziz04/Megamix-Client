const locales =  ['en', 'ru', 'uz', 'tr', 'tj']

module.exports = locales