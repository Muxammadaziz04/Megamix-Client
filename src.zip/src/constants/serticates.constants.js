const sertificates = ['/sertificates/1.png', '/sertificates/2.png' ,'/sertificates/3.png']

module.exports = sertificates