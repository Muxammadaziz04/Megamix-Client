const honors = [
    {
        id: 1,
        title: '',
        description: '',
        image: '/honors/1.jpg'
    },
    {
        id: 2,
        title: '',
        description: '',
        image: '/honors/2.jpg'
    },
    {
        id: 3,
        title: '',
        description: '',
        image: '/honors/3.jpg'
    },
    {
        id: 4,
        title: '',
        description: '',
        image: '/honors/4.png'
    },
]

export default honors